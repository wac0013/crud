function soma(n1, n2) {
  alert(n1 + n2);
}